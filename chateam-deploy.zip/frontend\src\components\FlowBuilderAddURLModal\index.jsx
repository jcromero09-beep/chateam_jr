import React, { useRef, useState } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid
} from "@material-ui/core";
import api from "../../services/api";
import toastError from "../../errors/toastError";

const useStyles = makeStyles((theme) => ({
  dialogTitleWrapper: {
    position: 'relative',
  },
  primaryBar: {
    position: 'absolute',
    top: 0,                
    left: 0,
    right: 0,
    height: '100%',          
    backgroundColor: theme.palette.primary.main,  
    zIndex: 1,              
  },
  dialogTitle: {
    position: 'relative',    
    zIndex: 2,               
    color: 'white',          
  },
  inputFile: {
    display: 'none',  
  },
}));

const FlowBuilderAddURLModal = ({ open, close, onSave, data }) => {
  const classes = useStyles();
  const [loading, setLoading] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [buttonText, setButtonText] = useState("");
  const [sendURL, setSendURL] = useState("");
  const [imageBase64, setImageBase64] = useState('');

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageBase64(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };


  const handleClose = () => {
    close(null);
  };

  

  const handleSave = () => {
    const urlData = {
      title,
      description,
      buttonText,
      url: sendURL,
      image: imageBase64
    };
    onSave(urlData);
    close();
  };

  return (
    <Dialog open={open} close={close} maxWidth="sm" fullWidth>
      <div className={classes.dialogTitleWrapper}>
        <div className={classes.primaryBar}></div>
        <DialogTitle className={classes.dialogTitle}>Configurar URL</DialogTitle>
      </div>

      <DialogContent>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <input
              accept="image/*"
              className={classes.inputFile}
              id="url-image-input"
              type="file"
              onChange={handleImageChange}
            />
            <label htmlFor="url-image-input">
              <Button
                variant="contained"
                color="primary"
                component="span"
                fullWidth
              >
                Subir Imagen
              </Button>
            </label>
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Título"
              variant="outlined"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Descripción"
              variant="outlined"
              multiline
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Texto del botón"
              variant="outlined"
              value={buttonText}
              onChange={(e) => setButtonText(e.target.value)}
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="URL"
              variant="outlined"
              value={sendURL}
              onChange={(e) => setSendURL(e.target.value)}
            />
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="default">
          Cancelar
        </Button>
        <Button color="primary" onClick={handleSave}>
          Confirmar
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FlowBuilderAddURLModal;