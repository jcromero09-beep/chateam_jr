import React, { useState, useEffect, useRef } from "react";

import * as Yup from "yup";
import { Formik, FieldArray, Form, Field } from "formik";
import { toast } from "react-toastify";

import { makeStyles } from "@material-ui/core/styles";
import { green } from "@material-ui/core/colors";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import CircularProgress from "@material-ui/core/CircularProgress";
import Compressor from "compressorjs";

import { i18n } from "../../translate/i18n";

import api from "../../services/api";
import toastError from "../../errors/toastError";
import { Stack } from "@mui/material";

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    flexWrap: "wrap"
  },
  textField: {
    marginRight: theme.spacing(1),
    flex: 1
  },

  extraAttr: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
  },

  btnWrapper: {
    position: "relative"
  },

  buttonProgress: {
    color: green[500],
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -12,
    marginLeft: -12
  }
}));


const FlowBuilderAddImgModal = ({ open, onSave, onUpdate, data, close }) => {
  const classes = useStyles();
  const isMounted = useRef(true);

  const [activeModal, setActiveModal] = useState(false);

  const [loading, setLoading] = useState(false);

  const [preview, setPreview] = useState();

  const [oldImage, setOldImage] = useState();

  const [labels, setLabels] = useState({
    title: "Añadir imagen al flujo",
    btn: "Añadir"
  });

  const [medias, setMedias] = useState([]);

  useEffect(() => {
    if (open === "edit") {
      setLabels({
        title: "Editar imagen",
        btn: "Guardar"
      });
      setOldImage(data.data.url)
      setPreview(process.env.REACT_APP_BACKEND_URL + '/public/' + data.data.url)
      setActiveModal(true);
    } else if (open === "create") {
      setLabels({
        title: "Añadir imagen al flujo",
        btn: "Añadir"
      });
      setActiveModal(true);
    } else {
      setActiveModal(false);
    }
  }, [open]);

  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);

  const handleClose = () => {
    close(null);
    setActiveModal(false);
  };

  const handleSaveContact = async () => {
    if (open === "edit") {
      handleClose();
      onUpdate({
        ...data,
        data: { url: "" }
      });
      return;
    } else if (open === "create") {
      setLoading(true);
      const formData = new FormData();
      formData.append("fromMe", true);

      try {
        // Process all media files and wait for compression
        const compressionPromises = medias.map((media) => {
          return new Promise((resolve, reject) => {
            const file = media;

            if (!file) {
              resolve();
              return;
            }

            if (media?.type.split("/")[0] === "image") {
              new Compressor(file, {
                quality: 0.7,
                success(compressedMedia) {
                  formData.append("medias", compressedMedia);
                  formData.append("body", compressedMedia.name);
                  resolve();
                },
                error(err) {
                  console.error("Compression error:", err);
                  reject(err);
                }
              });
            } else {
              formData.append("medias", media);
              formData.append("body", media.name);
              resolve();
            }
          });
        });

        // Wait for all compressions to complete
        await Promise.all(compressionPromises);

        console.log("FormData ready, uploading...");
        const res = await api.post("/flowbuilder/img", formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });

        handleClose();
        onSave({
          url: res.data.name
        });
        toast.success("¡Imagen añadida correctamente!");
        setLoading(false);
        setMedias([]);
        setPreview();
      } catch (error) {
        console.error("Upload error:", error);
        toast.error("Error al subir la imagen");
        setLoading(false);
      }
    }
  };

  const handleChangeMedias = e => {
    if (!e.target.files) {
      return;
    }

    if(e.target.files[0].size > 2000000){
      toast.error("El archivo es demasiado grande! 2MB máximo")
      return
    }

    const selectedMedias = Array.from(e.target.files);
    setPreview(URL.createObjectURL(e.target.files[0]));
    setMedias(selectedMedias);
  };

  return (
    <div className={classes.root}>
      <Dialog
        open={activeModal}
        onClose={handleClose}
        fullWidth="md"
        scroll="paper"
      >
        <DialogTitle id="form-dialog-title">{labels.title}</DialogTitle>
        <Stack>
          <DialogContent dividers>
            <Stack gap={"16px"}>
              {preview && <img src={preview} style={{ width: "552px" }} />}
              {!loading && open !== "edit" && (
                <Button variant="contained" component="label">
                  Enviar imagen
                  <input
                    type="file"
                    accept="image/png, image/jpg, image/jpeg"
                    disabled={loading}
                    hidden
                    onChange={handleChangeMedias}
                  />
                </Button>
              )}
              {loading && (
                <>
                  <Stack justifyContent={"center"} alignSelf={"center"}>
                    <CircularProgress />
                  </Stack>
                </>
              )}
            </Stack>
          </DialogContent>
          <DialogActions>
            {!loading && (
              <>
                <Button
                  onClick={() => {
                    handleClose();
                    setMedias([]);
                    setPreview();
                  }}
                  color="default"
                  variant="contained"
                >
                  {i18n.t("contactModal.buttons.cancel")}
                </Button>
                {open !== "edit" && (<Button
                  type="submit"
                  disabled={loading}
                  color="primary"
                  variant="contained"
                  className={classes.btnWrapper}
                  onClick={() => handleSaveContact()}
                >
                  {`${labels.btn}`}
                </Button>)}
              </>
            )}
          </DialogActions>
        </Stack>
      </Dialog>
    </div>
  );
};

export default FlowBuilderAddImgModal;
