import React, { useState, useEffect, useRef } from "react";

import * as Yup from "yup";
import { Formik, FieldArray, Form, Field } from "formik";
import { toast } from "react-toastify";

import { makeStyles } from "@material-ui/core/styles";
import { green } from "@material-ui/core/colors";
import Button from "@material-ui/core/Button";
import TextField from "@material-ui/core/TextField";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import Typography from "@material-ui/core/Typography";
import IconButton from "@material-ui/core/IconButton";
import DeleteOutlineIcon from "@material-ui/icons/DeleteOutline";
import CircularProgress from "@material-ui/core/CircularProgress";
import Compressor from "compressorjs";

import { i18n } from "../../translate/i18n";

import api from "../../services/api";
import toastError from "../../errors/toastError";
import Checkbox from "@material-ui/core/Checkbox";
import Box from "@material-ui/core/Box";

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    flexWrap: "wrap"
  },
  textField: {
    marginRight: theme.spacing(1),
    flex: 1
  },

  extraAttr: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
  },

  btnWrapper: {
    position: "relative"
  },

  buttonProgress: {
    color: green[500],
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -12,
    marginLeft: -12
  }
}));

const FlowBuilderAddAudioModal = ({ open, onSave, onUpdate, data, close }) => {
  const classes = useStyles();
  const isMounted = useRef(true);

  const [activeModal, setActiveModal] = useState(false);

  const [loading, setLoading] = useState(false);

  const [record, setRecord] = useState(false);

  const [preview, setPreview] = useState();

  const [labels, setLabels] = useState({
    title: "Añadir audio a la transmisión",
    btn: "Añadir"
  });

  const [textDig, setTextDig] = useState();

  const [medias, setMedias] = useState([]);

  useEffect(() => {
    if (open === "edit") {
      setLabels({
        title: "Editar audio",
        btn: "Guardar"
      });
      setPreview(process.env.REACT_APP_BACKEND_URL + '/public/' + data.data.url)
      setRecord(data.data.record)
      setActiveModal(true);
    } else if (open === "create") {
      setLabels({
        title: "Añadir audio a la transmisión",
        btn: "Añadir"
      });
      setTextDig("");
      setActiveModal(true);
    } else {
      setActiveModal(false);
    }
  }, [open]);

  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);

  const handleClose = () => {
    close(null);
    setActiveModal(false);
  };

  const handleSaveContact = async () => {
    if (open === "edit") {
      handleClose();
      onUpdate({
        ...data,
        data: { url: data.data.url,
        record: record }
      });
      return;
    } else if (open === "create") {
      setLoading(true);
      const formData = new FormData();
      formData.append("fromMe", true);

      try {
        // Process all media files and wait for compression
        const compressionPromises = medias.map((media) => {
          return new Promise((resolve, reject) => {
            const file = media;

            if (!file) {
              resolve();
              return;
            }

            if (media?.type.split("/")[0] === "image") {
              new Compressor(file, {
                quality: 0.7,
                success(compressedMedia) {
                  formData.append("medias", compressedMedia);
                  formData.append("body", compressedMedia.name);
                  resolve();
                },
                error(err) {
                  console.error("Compression error:", err);
                  reject(err);
                }
              });
            } else {
              formData.append("medias", media);
              formData.append("body", media.name);
              resolve();
            }
          });
        });

        // Wait for all compressions to complete
        await Promise.all(compressionPromises);

        console.log("FormData ready, uploading...");
        const res = await api.post("/flowbuilder/audio", formData, {
          headers: {
            'Content-Type': 'multipart/form-data'
          }
        });

        handleClose();
        onSave({
          url: res.data.name,
          record: record
        });
        toast.success("¡Audio añadido correctamente!");
        setLoading(false);
        setMedias([]);
        setPreview();
      } catch (error) {
        console.error("Upload error:", error);
        toast.error("Error al subir el audio");
        setLoading(false);
      }
    }
  };

  const handleChangeMedias = e => {
    if (!e.target.files) {
      return;
    }

    if(e.target.files[0].size > 5000000){
      toast.error("El archivo es demasiado grande. 5MB máximo")
      return
    }

    const selectedMedias = Array.from(e.target.files);
    setPreview((URL.createObjectURL(e.target.files[0])));
    setMedias(selectedMedias);
  };

  return (
    <div className={classes.root}>
      <Dialog
        open={activeModal}
        onClose={handleClose}
        fullWidth="md"
        scroll="paper"
      >
        <DialogTitle id="form-dialog-title">{labels.title}</DialogTitle>
        <Box>
          <DialogContent dividers>
            <Box display="flex" flexDirection="column" gridGap={16}>
              {preview && (
                <Box display="flex" flexDirection="row" justifyContent="center">
                <audio controls="controls">
                  <source src={preview} type="audio/mp3" />
                  tu navegador no soporta HTML5
                </audio>
                </Box>
              )}
              {preview && (
                <Box display="flex" flexDirection="row" justifyContent="center">
                <Checkbox checked={record} onChange={(e) => setRecord(old => !old)}/>
                <Box display="flex" justifyContent="center">
                <Typography>Enviar como audio grabado</Typography>
                </Box>
                </Box>
              )}
              {!loading && open !== "edit" && (
                <Button variant="contained" component="label">
                  Enviar audio
                  <input
                    type="file"
                    accept="audio/ogg, audio/mp3"
                    disabled={loading}
                    hidden
                    onChange={handleChangeMedias}
                  />
                </Button>
              )}
              {loading && (
                <>
                  <Box display="flex" justifyContent="center" alignSelf="center">
                    <CircularProgress />
                  </Box>
                </>
              )}
            </Box>
          </DialogContent>
          <DialogActions>
            {!loading && (
              <>
                <Button
                  onClick={() => {
                    handleClose();
                    setMedias([]);
                    setPreview();
                  }}
                  color="default"
                  variant="contained"
                >
                  {i18n.t("contactModal.buttons.cancel")}
                </Button>
                <Button
                  type="submit"
                  disabled={loading}
                  color="primary"
                  variant="contained"
                  className={classes.btnWrapper}
                  onClick={() => handleSaveContact()}
                >
                  {`${labels.btn}`}
                </Button>
              </>
            )}
          </DialogActions>
        </Box>
      </Dialog>
    </div>
  );
};

export default FlowBuilderAddAudioModal;
