import React, { useState, useEffect } from "react";
import { makeStyles } from "@material-ui/core/styles";
import {
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Grid,
  IconButton,
  Typography
} from "@material-ui/core";
import { Add, Delete } from "@material-ui/icons";
import toastError from "../../errors/toastError";

const useStyles = makeStyles((theme) => ({
  dialogTitleWrapper: {
    position: 'relative',
  },
  primaryBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: '100%',
    backgroundColor: theme.palette.primary.main,
    zIndex: 1,
  },
  dialogTitle: {
    position: 'relative',
    zIndex: 2,
    color: 'white',
  },
  optionContainer: {
    display: 'flex',
    alignItems: 'center',
    marginBottom: theme.spacing(1),
    gap: theme.spacing(1)
  }
}));

const FlowBuilderAddListModal = ({ open, onClose, onSave, onUpdate, data, close }) => {
  const classes = useStyles();
  const [loading, setLoading] = useState(false);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  //const [options, setOptions] = useState([{ text: "", value: "" }]);
  const [options, setOptions] = useState([""]);
  const [activeModal, setActiveModal] = useState(false);
  const [labels, setLabels] = useState({
    title: "Crear Lista",
    btn: "Crear"
  });

  useEffect(() => {
    if (open === "edit") {
      setLabels({
        title: "Editar Lista",
        btn: "Actualizar"
      });
      if (data && data.data) {
        setTitle(data.data.title || "");
        setDescription(data.data.description || "");
        setOptions((data.data.options || []).map(opt => typeof opt === "string" ? opt : opt.text));
      }
      setActiveModal(true);
    } else if (open === "create") {
      setLabels({
        title: "Crear Lista",
        btn: "Crear"
      });
      setTitle("");
      setDescription("");
      setOptions([""]);
      setActiveModal(true);
    } else {
      setActiveModal(false);
    }
  }, [open]);


  const handleClose = () => {
    close(null);
    setActiveModal(false);
    setTitle("");
    setDescription("");
    setOptions([""]);
  };

  const handleSave = () => {
    if (!title.trim()) {
      toastError("El título es requerido");
      return;
    }

    // const validOptions = options.filter(option => option.trim() !== "");
    // if (validOptions.length === 0) {
    //   alert("Debe tener al menos una opción");
    //   return;
    // }

    const validOptions = options
      .map(opt => opt.trim())
      .filter(opt => opt !== "");

    if (validOptions.length === 0) {
      toastError("Debe tener al menos una opción");
      return;
    }

    // Validar duplicados
    const uniqueOptions = new Set(validOptions);
    if (uniqueOptions.size !== validOptions.length) {
      toastError("No se permiten opciones duplicadas");
      return;
    }

    // Se guarda como [{ text: "Opción 1", value: "Opción 1" }]
    const listData = {
      title: title.trim(),
      description: description.trim(),
      options: validOptions.map(opt => ({ text: opt.trim(), value: opt.trim() }))
    };

    if (open === "edit") {
      onUpdate({
        ...data,
        data: listData
      });
    } else {
      onSave(listData);
    }

    handleClose();
  };


  const addOption = () => {
    setOptions([...options, ""]);
  };

  const removeOption = (index) => {
    if (options.length > 1) {
      const newOptions = options.filter((_, i) => i !== index);
      setOptions(newOptions);
    }
  };

  const updateOption = (index, value) => {
    const newOptions = [...options];
    newOptions[index] = value;
    setOptions(newOptions);
  };


  return (
    <Dialog open={activeModal} onClose={handleClose} maxWidth="sm" fullWidth>
      <div className={classes.dialogTitleWrapper}>
        <div className={classes.primaryBar}></div>
        <DialogTitle className={classes.dialogTitle}>{labels.title}</DialogTitle>
      </div>

      <DialogContent>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Título"
              variant="outlined"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              fullWidth
              label="Descripción"
              variant="outlined"
              multiline
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </Grid>
          <Grid item xs={12}>
            <Typography variant="subtitle1" style={{ marginBottom: 8 }}>
              Opciones
            </Typography>
            {options.map((option, index) => (
              <div key={index} className={classes.optionContainer}>
                <TextField
                  label={`Opción ${index + 1}`}
                  variant="outlined"
                  size="small"
                  value={option}
                  onChange={(e) => updateOption(index, e.target.value)}
                  style={{ flex: 1 }}
                />
                <IconButton
                  color="secondary"
                  onClick={() => removeOption(index)}
                  disabled={options.length === 1}
                >
                  <Delete />
                </IconButton>
              </div>
            ))}

            <Button
              startIcon={<Add />}
              onClick={addOption}
              color="primary"
              variant="outlined"
              size="small"
            >
              Agregar Opción
            </Button>
          </Grid>
        </Grid>
      </DialogContent>
      <DialogActions>
        <Button onClick={handleClose} color="default">
          Cancelar
        </Button>
        <Button color="primary" onClick={handleSave}>
          {labels.btn}
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default FlowBuilderAddListModal;