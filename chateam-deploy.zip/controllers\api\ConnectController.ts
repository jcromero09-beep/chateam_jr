import { Request, Response } from "express";
import * as Yup from "yup";
import User from "../../models/User";
import Whatsapp from "../../models/Whatsapp";

interface ConnectRequest {
  email: string;
  password: string;
}

/**
 * POST /api/connect
 * Endpoint público para obtener credenciales de conexión WhatsApp
 * Recibe: email y password de un usuario Chateam
 * Devuelve: whatsappId, token, companyId y datos de la conexión por defecto
 */
export const connect = async (req: Request, res: Response): Promise<Response> => {
  const { email, password }: ConnectRequest = req.body;

  // 1. Validación de entrada con Yup
  const schema = Yup.object().shape({
    email: Yup.string()
      .email("ERR_INVALID_EMAIL_FORMAT")
      .required("ERR_EMAIL_REQUIRED"),
    password: Yup.string()
      .required("ERR_PASSWORD_REQUIRED")
      .min(1, "ERR_PASSWORD_REQUIRED")
  });

  try {
    await schema.validate({ email, password });
  } catch (err: any) {
    return res.status(400).json({
      success: false,
      error: err.message,
      code: "VALIDATION_ERROR"
    });
  }

  // 2. Buscar usuario por email
  const user = await User.findOne({
    where: { email: email.toLowerCase().trim() }
  });

  if (!user) {
    return res.status(401).json({
      success: false,
      error: "Usuario no encontrado",
      code: "USER_NOT_FOUND"
    });
  }

  // 3. Validar password
  const isPasswordValid = await user.checkPassword(password);
  if (!isPasswordValid) {
    return res.status(401).json({
      success: false,
      error: "Contraseña incorrecta",
      code: "INVALID_PASSWORD"
    });
  }

  // 4. Obtener conexión por defecto de la empresa
  // Prioridad: 1) WhatsApp asignado al usuario, 2) Default de la empresa, 3) Cualquier CONNECTED
  const companyId = user.companyId;
  let defaultWhatsapp: Whatsapp | null = null;

  // 4a. Verificar si el usuario tiene WhatsApp asignado
  if (user.whatsappId) {
    defaultWhatsapp = await Whatsapp.findOne({
      where: {
        id: user.whatsappId,
        companyId,
        status: "CONNECTED"
      }
    });
  }

  // 4b. Si no, buscar el default de la empresa
  if (!defaultWhatsapp) {
    defaultWhatsapp = await Whatsapp.findOne({
      where: {
        companyId,
        isDefault: true,
        status: "CONNECTED"
      }
    });
  }

  // 4c. Si no hay default, buscar cualquier conexión CONNECTED
  if (!defaultWhatsapp) {
    defaultWhatsapp = await Whatsapp.findOne({
      where: {
        companyId,
        status: "CONNECTED"
      }
    });
  }

  // 5. Validar que exista conexión disponible
  if (!defaultWhatsapp) {
    return res.status(404).json({
      success: false,
      error: "No hay conexión WhatsApp disponible para esta empresa",
      code: "NO_WHATSAPP_CONNECTION"
    });
  }

  // 6. Verificar que el token exista
  if (!defaultWhatsapp.token) {
    return res.status(500).json({
      success: false,
      error: "La conexión WhatsApp no tiene token configurado",
      code: "NO_API_TOKEN"
    });
  }

  // 7. Retornar credenciales de API
  return res.status(200).json({
    success: true,
    data: {
      whatsappId: defaultWhatsapp.id,
      token: defaultWhatsapp.token,
      companyId: defaultWhatsapp.companyId,
      whatsappName: defaultWhatsapp.name,
      whatsappNumber: defaultWhatsapp.number || null,
      status: defaultWhatsapp.status,
      channel: defaultWhatsapp.channel || "whatsapp"
    }
  });
};
